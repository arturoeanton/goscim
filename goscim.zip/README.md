# goscim
SCIM server written in Go
